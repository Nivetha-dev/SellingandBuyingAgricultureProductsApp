package com.prgguru.showdirection;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class DataParser {

    private HashMap<String,String> getDuration(JSONArray googleDirectionsJSON)
    {
        HashMap<String,String> googledirectionsmap=new HashMap<>();
        String duration="";
        String distance="";
        Log.d("json response", googleDirectionsJSON.toString());
        try {
            duration=googleDirectionsJSON.getJSONObject(0).getJSONObject("duration").getString("text");
            distance=googleDirectionsJSON.getJSONObject(0).getJSONObject("distance").getString("text");

            googledirectionsmap.put("duration",duration);
            googledirectionsmap.put("distance",distance);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return googledirectionsmap;
    }

    public HashMap<String,String> parseDirections(String jsonData)
    {
        JSONArray jsonArray=null;
        JSONObject jsonObject;
        try {
            jsonObject=new JSONObject(jsonData);
            jsonArray=jsonObject.getJSONArray("routes").getJSONObject(0).getJSONArray("legs"); //legs array

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return getDuration(jsonArray);
    }
}
