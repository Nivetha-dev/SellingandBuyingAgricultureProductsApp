package com.prgguru.showdirection;

import android.os.AsyncTask;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.HashMap;

public class GetDirectionData extends AsyncTask<Object,String,String> {

    GoogleMap mMap;
    String url;
    String googleDirectionsData;
    String duration,distance;
    LatLng latLng;

    @Override
    protected String doInBackground(Object... objects) {
        mMap=(GoogleMap)objects[0];
        url=(String)objects[1];
        latLng=(LatLng)objects[2];

        DownloadURL downloadurl=new DownloadURL();
        try {
            googleDirectionsData = downloadurl.readURL(url);
        }catch (IOException e)
        {
e.printStackTrace();
        }
return googleDirectionsData;

    }

    @Override
    protected void onPostExecute(String s) {
        HashMap<String,String> directionlist=null;
        DataParser parser=new DataParser();
        directionlist=parser.parseDirections(url);
        duration=directionlist.get("duration");
        distance=directionlist.get("distance");

        mMap.clear();
        MarkerOptions markerOptions=new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.draggable(true);
        markerOptions.title("Duration =" + duration + "/n" + " Distance = " + distance);
        markerOptions.snippet("Distance = " + distance);
        mMap.addMarker(markerOptions);

    }
}
