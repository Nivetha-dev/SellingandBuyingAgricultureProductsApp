package com.prgguru.jersey;
//Change these parameters according to your DB
public class Constants {
	public static String dbClass = "com.mysql.jdbc.Driver";
	private static String dbName= "users";
	public static String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
	public static String dbUser = "root";
	public static String dbPwd = "password";
}