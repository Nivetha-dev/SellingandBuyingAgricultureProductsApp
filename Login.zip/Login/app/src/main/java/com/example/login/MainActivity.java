package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter=5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name=(EditText)findViewById(R.id.edtName);
        Password=(EditText)findViewById(R.id.edtPassword);
        Info=(TextView)findViewById((R.id.tvAttempt));
        Login=(Button)findViewById((R.id.btnLogin));

        Login.setOnClickListener(new View.OnClickListener() {
        public  void onClick(View v){
            JSONObject postData=new JSONObject();
            try
            {
                postData.put("username",Name.getText().toString());
                postData.put("password",Password.getText().toString());
                new SendDeviceDetails().execute("http://localhost:8080/FirstREST_war_exploded/login/dologin",postData.toString());
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
        }
        });


//        Info.setText("No of attempts remaining: 5");
//
//        Login.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                validate(Name.getText().toString(),Password.getText().toString());
//            }
//        });
    }
    private class SendDeviceDetails extends AsyncTask<String,Void,String> {

        @Override
        protected String doInBackground(String... params) {

           String data="";

            HttpURLConnection httpURLConnection = null;
            try {

                httpURLConnection = (HttpURLConnection) new URL(params[0]).openConnection();
                httpURLConnection.setRequestMethod("POST");

                httpURLConnection.setDoOutput(true);

                DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
                wr.writeBytes("PostData=" + params[1]);
                wr.flush();
                wr.close();

                InputStream in = httpURLConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(in);

                int inputStreamData = inputStreamReader.read();
                while (inputStreamData != -1) {
                    char current = (char) inputStreamData;
                    inputStreamData = inputStreamReader.read();
                    data += current;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
            }

            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Info.setText(result);
            Log.e("TAG", result); // this is expecting a response code to be sent from your server upon receiving the POST data
        }
    }
    //    private void validate(String userName,String userPassword)
//    {
//        if((userName=="Admin")&& (userPassword=="1234"))
//        {
//            Intent intent=new Intent(MainActivity.this,SecondActivity.class);
//            startActivity((intent));
//        }
//        else
//        {
//            counter--;
//            Info.setText("No of attempts remaining: " + String.valueOf(counter));
//            if(counter==0)
//            {
//                Login.setEnabled(false);
//            }
//        }
//    }
}
