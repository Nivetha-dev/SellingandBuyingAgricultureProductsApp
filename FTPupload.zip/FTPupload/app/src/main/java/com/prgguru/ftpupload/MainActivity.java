package com.prgguru.ftpupload;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.animation.MatrixEvaluator;
import com.nbsp.materialfilepicker.MaterialFilePicker;
import com.nbsp.materialfilepicker.ui.FilePickerActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketException;

import javax.xml.transform.Result;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

public class MainActivity extends AppCompatActivity {

    Button button;
    File fileupload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button=findViewById(R.id.upload);

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M)
        {
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
            {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},100);
                    return;
                }
            }
        }
        new MyTask().execute();
       // button_upload();
    }
    public void button_upload(){

    }
    private class MyTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                FTPClient ftpClient = new FTPClient();
                //ftpClient.setDefaultTimeout(1000 * 60);
                ftpClient.connect("ec2-3-18-59-14.us-east-2.compute.amazonaws.com",21);
                ftpClient.login("nivi123", "nivi123");
              //  fileupload = new File(Environment.getExternalStorageDirectory(), "Folder_Name/video/1582339221149.mp4");
                System.out.println("status is  :: " + ftpClient.getStatus());
                //String replyCode = ftpClient.getStatus();
//log or check response

                ftpClient.enterLocalPassiveMode();
                //ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

                InputStream inputStream = new FileInputStream(fileupload);
                ftpClient.storeFile("C:/FTP", inputStream);
                inputStream.close();

               // replyCode = ftpClient.getStatus();

                //                new MaterialFilePicker()
//                        .withActivity(MainActivity.this)
//                        .withRequestCode(10)
//                        .start();
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==100 && (grantResults[0]==PackageManager.PERMISSION_GRANTED)){

            //button_upload();
        }else{
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},100);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == 10 && resultCode == RESULT_OK) {
//Thread t=new Thread(new Runnable() {
//    @Override
//    public void run() {
//        File f=new File(data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH));
//        String content_type=getMimeType(f.)
//    }
//});
//t.start();
//        }
    }

    public void button(View view) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }

        });
    }
}
