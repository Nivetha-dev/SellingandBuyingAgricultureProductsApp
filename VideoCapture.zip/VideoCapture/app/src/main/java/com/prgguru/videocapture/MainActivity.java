package com.prgguru.videocapture;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends Activity {
    private final int VIDEO_REQ=100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void CaptureVideo(View view) {
        Intent camera_intent  = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if(camera_intent.resolveActivity(getPackageManager())!=null) {

           // File video_file = getFilepath();
           // Uri video_uri = Uri.fromFile(video_file);
            File video_file=new File(Environment.getExternalStorageDirectory(),"/Record/vid_" + String.valueOf(System.currentTimeMillis()) + ".mp4");
            Uri video_uri=Uri.fromFile(video_file);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N)
            {
                video_uri= FileProvider.getUriForFile(getApplicationContext(),BuildConfig.APPLICATION_ID+".provider",video_file);
            }
            camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, video_uri);
            camera_intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
            startActivityForResult(camera_intent, VIDEO_REQ);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==VIDEO_REQ)
        {
            if(requestCode==RESULT_OK)
            {
                Toast.makeText(getApplicationContext(),"Video Successfully uploaded",Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Video Capture Failed...",Toast.LENGTH_LONG).show();
            }
        }

    }

    public File getFilepath()
    {
        File folder= new File("sdcard/Audio");
        if(!folder.exists())
        {
            folder.mkdir();
        }
File video_file=new File(folder,"sample_video.mp4");
        return video_file;
    }
}
