package com.prgguru.getlatlng;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int Req_Loc=1;

    Button getLocationbtn;
    TextView showLocationTxt;

    LocationManager locationManager;
    String lattitude,longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},Req_Loc);
        showLocationTxt=findViewById(R.id.show_location);
        getLocationbtn=findViewById(R.id.getlocation);

        getLocationbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);

                //check gps is enabled or not

                if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                {
                    //write function to enable gps

                    onGPS();
                }
                else
                {
                    //GPS is already on then
                    getlocation();
                }
            }
        });

    }

    private void getlocation() {
        //check permission again

        if(ActivityCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this
        ,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},Req_Loc);
        }
        else
        {
            Location Locationgps=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location LocationNetwork=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location Locationpassive=locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

            if(Locationgps!=null)
            {
                double lat=Locationgps.getLatitude();
                double longi=Locationgps.getLongitude();

                lattitude=String.valueOf(lat);
                longitude=String.valueOf(longi);

                showLocationTxt.setText("Your Location" + "\n" +"Latitude = " + lattitude + "\n" + "Longitude = " + longitude);
            }
            else if(LocationNetwork!=null)
            {
                double lat=LocationNetwork.getLatitude();
                double longi=LocationNetwork.getLongitude();

                lattitude=String.valueOf(lat);
                longitude=String.valueOf(longi);

                showLocationTxt.setText("Your Location" + "\n" +"Latitude = " + lattitude + "\n" + "Longitude = " + longitude);
            }
            else  if(Locationpassive!=null)
            {
                double lat=Locationpassive.getLatitude();
                double longi=Locationpassive.getLongitude();

                lattitude=String.valueOf(lat);
                longitude=String.valueOf(longi);

                showLocationTxt.setText("Your Location" + "\n" +"Latitude = " + lattitude + "\n" + "Longitude = " + longitude);
            }
            else
            {
                Toast.makeText(this, "cannot find your location", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void onGPS()
    {
        final AlertDialog.Builder builder=new AlertDialog.Builder(this);

        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
    final AlertDialog alertDialog=builder.create();
    alertDialog.show();
    }
}
